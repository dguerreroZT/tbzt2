These icons are from Icojam (http://www.icojam.com)

Blue Bits Basic and Bonus [bitmap]

Ammount of icons:
124

Icon Sizes:
16x16, 32x32, 48x48, 128x128, 256x256

File Types:
.png: 
256x256(32bit)
128x128(32bit)
48x48(32bit)
32x32(32bit)
16x16(32bit)

.ico: 
256x256(xp/vista)
128x128(xp)
48x48(xp,8bit)
32x32(xp,8bit)
16x16(xp,8bit)

.icns: 
256x256(rgb/a)
128x128(rgb/a)
48x48(rgb/a,8bit,mono)
32x32(rgb/a,8bit,mono)
16x16(rgb/a,8bit,mono)